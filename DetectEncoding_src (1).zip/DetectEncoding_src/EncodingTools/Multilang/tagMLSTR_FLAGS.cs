namespace MultiLanguage
{
    using System;
    using System.Security;

    public enum tagMLSTR_FLAGS
    {
        MLSTR_READ = 1,
        MLSTR_WRITE = 2
    }
}
